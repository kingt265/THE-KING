package controllers;

import app.AnniversariesApp;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.Anniversary;
import model.Place;
import repositories.Repository;
import viewmodels.AnniversaryView;
import views.RootLayoutController;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

public class Controller {
    private Stage primaryStage;
    private BorderPane rootLayout;


   public Controller(Stage primaryStage) {
        this.primaryStage = primaryStage;
   }

   public void initRootLayout() {
        try {
           FXMLLoader loader = new FXMLLoader();
           loader.setLocation(AnniversariesApp.class.getResource("/views/RootLayout.fxml"));

           rootLayout = (BorderPane) loader.load();

           Scene scene = new Scene(rootLayout);
           primaryStage.setScene(scene);

           RootLayoutController rootLayoutController = loader.getController();
           rootLayoutController.setMainController(this);

           primaryStage.show();
           listAnniversaries();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void listAnniversaries() {
        // tbc
    }
}
